於MyFirstApp專案修改了以下 : 
把Hello World 改成 Hello Kitty! 
字體放大至80
背景顏色
改變ICON